
<!-- README.md is generated from README.Rmd. Please edit that file -->
neyhart
=======

A collection of useful, but disparate functions that I often use.

Installation
------------

You can install neyhart from github with:

``` r
# install.packages("devtools")
devtools::install_github("neyhartj/neyhart")
```

Functions
---------
