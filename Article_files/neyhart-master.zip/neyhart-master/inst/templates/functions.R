## Project name here
## 
## This is a script with ad hoc functions for this project
## 

