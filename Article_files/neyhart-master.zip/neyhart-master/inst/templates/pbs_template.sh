#!/bin/bash

#PBS -l walltime=08:00:00,mem=24gb,nodes=1:ppn=1
#PBS -N script_name
#PBS -M user@email.com
#PBS -m abe
#PBS -r n

# Change the working directory
cd 

# Load modules


# Run the script


