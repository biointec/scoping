#' Create a new project
#' 
#' @description 
#' Creates a new project repository with the accoutrements that I find useful.
#' 
#' @import devtools
#' 
#' 
create_project <- function(path = ".") {
  
  # First check if the directory already has a project
  
  
  
   
}




#' Create a repository README
#' 
#' 
#' 
#' 
